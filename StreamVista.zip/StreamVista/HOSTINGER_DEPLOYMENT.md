# StreamlyHub - Hostinger Deployment Guide

## 📁 Download Your Production Files

Your production-ready StreamlyHub application is now built and packaged! Here's how to get it and deploy it to Hostinger:

## Step 1: Download the Production Package

1. In Replit, look for the file `streamlyhub-production.zip` in the file explorer
2. Right-click on `streamlyhub-production.zip` and select "Download"
3. Save it to your computer

**Alternative Download Method:**
- Use the Replit "Export as ZIP" feature to download the entire project
- Extract only the `dist/` folder contents for deployment

## Step 2: Prepare Your Hostinger Account

### Prerequisites:
- Hostinger web hosting account with Node.js support
- A domain name configured with Hostinger
- Firebase project with authentication set up

### Check Node.js Support:
1. Log into Hostinger hPanel
2. Go to Advanced → Node.js
3. Ensure Node.js 18+ is available and enabled for your domain

## Step 3: Upload Files to Hostinger

### Upload Frontend Files:
1. In Hostinger File Manager, navigate to `public_html/`
2. Upload ALL files from the `public/` folder:
   - `index.html`
   - `assets/` folder (contains CSS and JS files)
   - `.htaccess` file

### Upload Backend Files:
1. Go to your domain root directory (one level up from public_html)
2. Upload these files:
   - `index.js` (main server file)
   - `package.json` (dependencies)
   - `start.js` (startup script)
   - `.env.example` (environment template)

## Step 4: Configure Environment Variables

### In Hostinger hPanel:
1. Go to Advanced → Environment Variables
2. Add these variables with your Firebase details:

```
NODE_ENV=production
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_PROJECT_ID=your_firebase_project_id
VITE_FIREBASE_APP_ID=your_firebase_app_id
PORT=5000
```

### Get Firebase Configuration:
1. Go to Firebase Console → Project Settings
2. Under "Your apps" section, find your web app
3. Copy the config values (apiKey, projectId, appId)

## Step 5: Install Dependencies and Start

### In Hostinger Terminal:
```bash
# Navigate to your domain root
cd /home/username/domains/yourdomain.com

# Install production dependencies
npm install

# Start the application
npm start
```

### Alternative Startup:
```bash
# Using the startup script
node start.js
```

## Step 6: Configure Firebase for Your Domain

1. Go to Firebase Console → Authentication → Settings
2. Under "Authorized domains", add:
   - `yourdomain.com`
   - `www.yourdomain.com`
3. Save the changes

## Step 7: Enable SSL (Important!)

1. In Hostinger hPanel, go to Security → SSL/TLS
2. Enable SSL certificate for your domain
3. Force HTTPS redirection
4. Firebase requires HTTPS for authentication in production

## Step 8: Test Your Deployment

1. Visit `https://yourdomain.com`
2. You should see the StreamlyHub homepage
3. Test the age verification modal
4. Try logging in with Google authentication
5. Check that all pages load correctly

## 🔧 Troubleshooting Common Issues

### Authentication Not Working:
- Check Firebase authorized domains
- Verify environment variables are set correctly
- Ensure HTTPS is enabled

### 404 Errors on Page Refresh:
- Verify `.htaccess` file is in public_html
- Check that URL rewriting is enabled in Hostinger

### Server Not Starting:
- Check Node.js version compatibility
- Verify all files are uploaded correctly
- Check error logs in Hostinger control panel

### Environment Variables Not Loading:
- Make sure they're set in Hostinger hPanel, not just in files
- Restart the Node.js application after setting variables

## 📁 File Structure After Deployment

```
yourdomain.com/
├── public_html/                 # Frontend files
│   ├── index.html
│   ├── assets/
│   │   ├── index-*.css
│   │   └── index-*.js
│   └── .htaccess
├── index.js                     # Backend server
├── package.json                 # Dependencies
├── start.js                     # Startup script
├── .env.example                 # Environment template
└── node_modules/                # Installed packages
```

## 🎯 Next Steps After Deployment

1. **Test All Features**: Go through each page and feature
2. **Monitor Performance**: Check loading times and responsiveness
3. **Set Up Monitoring**: Configure error logging and uptime monitoring
4. **Backup**: Create regular backups of your application
5. **Updates**: Keep dependencies updated for security

## 🆘 Need Help?

1. Check Hostinger documentation for Node.js hosting
2. Verify your hosting plan supports Node.js applications
3. Contact Hostinger support for server-specific issues
4. Refer to Firebase documentation for authentication problems

## 🎉 Congratulations!

Your StreamlyHub platform is now live on Hostinger! Users can access all features including video chat, live streaming, the virtual gift economy, and admin management tools.

---

**Remember**: Always use HTTPS in production and keep your Firebase credentials secure!