import { Switch, Route, Link } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { Navbar, BottomNavigation, FloatingActionButton } from "@/components/ui/navigation";
import AgeVerificationModal from "@/components/age-verification-modal";
import HomePage from "@/pages/home";
import VideoChatPage from "@/pages/video-chat";
import LiveStreamsPage from "@/pages/live-streams";
import WalletPage from "@/pages/wallet";
import DiscoveryPage from "@/pages/discovery";
import AdminPage from "@/pages/admin";
import AuthPage from "@/pages/auth";
import NotFound from "@/pages/not-found";
import PrivacyPolicyPage from "@/pages/legal/privacy";
import TermsPage from "@/pages/legal/terms";
import ContentDisclaimerPage from "@/pages/legal/content-disclaimer";
import ContactPage from "@/pages/legal/contact";
import AboutPage from "@/pages/legal/about";
import HelpPage from "@/pages/legal/help";
import { Loader2 } from "lucide-react";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { firebaseUser, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-darkBg">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!firebaseUser) {
    return <AuthPage />;
  }

  return <>{children}</>;
}

function AppContent() {
  return (
    <div className="min-h-screen bg-darkBg text-textPrimary">
      <AgeVerificationModal />
      <Switch>
        <Route path="/auth" component={AuthPage} />
        
        {/* Legal pages - public access */}
        <Route path="/privacy" component={PrivacyPolicyPage} />
        <Route path="/terms" component={TermsPage} />
        <Route path="/content-disclaimer" component={ContentDisclaimerPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/help" component={HelpPage} />
        
        <Route>
          <ProtectedRoute>
            <Navbar />
            <main className="max-w-7xl mx-auto px-4 py-6 pb-20 md:pb-6">
              <Switch>
                <Route path="/" component={HomePage} />
                <Route path="/chat" component={VideoChatPage} />
                <Route path="/discovery" component={DiscoveryPage} />
                <Route path="/admin" component={AdminPage} />
                <Route path="/streams" component={LiveStreamsPage} />
                <Route path="/wallet" component={WalletPage} />
                <Route component={NotFound} />
              </Switch>
            </main>
            <BottomNavigation />
            <FloatingActionButton />
            
            {/* Footer with legal links */}
            <footer className="bg-cardBg border-t border-gray-700 mt-16 py-8">
              <div className="max-w-7xl mx-auto px-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div>
                    <h3 className="text-textPrimary font-semibold mb-3">Legal</h3>
                    <div className="space-y-2">
                      <Link href="/privacy">
                        <span className="block text-gray-400 hover:text-primary transition-colors cursor-pointer">Privacy Policy</span>
                      </Link>
                      <Link href="/terms">
                        <span className="block text-gray-400 hover:text-primary transition-colors cursor-pointer">Terms of Service</span>
                      </Link>
                      <Link href="/content-disclaimer">
                        <span className="block text-gray-400 hover:text-primary transition-colors cursor-pointer">Content Disclaimer</span>
                      </Link>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-textPrimary font-semibold mb-3">Support</h3>
                    <div className="space-y-2">
                      <Link href="/help">
                        <span className="block text-gray-400 hover:text-primary transition-colors cursor-pointer">Help Center</span>
                      </Link>
                      <Link href="/contact">
                        <span className="block text-gray-400 hover:text-primary transition-colors cursor-pointer">Contact Us</span>
                      </Link>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-textPrimary font-semibold mb-3">Company</h3>
                    <div className="space-y-2">
                      <Link href="/about">
                        <span className="block text-gray-400 hover:text-primary transition-colors cursor-pointer">About Us</span>
                      </Link>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-textPrimary font-semibold mb-3">StreamlyHub</h3>
                    <p className="text-gray-400 text-sm">Connecting people through live streaming and authentic conversations.</p>
                    <p className="text-gray-400 text-xs mt-4">© 2025 StreamlyHub. All rights reserved.</p>
                  </div>
                </div>
              </div>
            </footer>
          </ProtectedRoute>
        </Route>
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <AppContent />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
