import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Eye, Gift } from "lucide-react";
import { Stream, User } from "@shared/schema";

interface StreamCardProps {
  stream: Stream & { streamer: User };
  size?: "small" | "large";
  onGiftClick?: () => void;
}

export function StreamCard({ stream, size = "small", onGiftClick }: StreamCardProps) {
  const isLarge = size === "large";

  return (
    <Card className="bg-cardBg border-gray-700 overflow-hidden hover:scale-105 transition-transform cursor-pointer">
      <div className="relative">
        <img 
          src={stream.thumbnail || "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=225"} 
          alt={stream.title}
          className={`w-full object-cover ${isLarge ? "h-64" : "h-32"}`}
        />
        {stream.isLive && (
          <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-500 text-white animate-pulse">
            <div className="w-2 h-2 bg-white rounded-full mr-1"></div>
            LIVE
          </Badge>
        )}
        <div className="absolute top-2 right-2 bg-black bg-opacity-60 text-white px-2 py-1 rounded text-xs flex items-center">
          <Eye className="h-3 w-3 mr-1" />
          {stream.viewerCount?.toLocaleString() || 0}
        </div>
      </div>
      
      <CardContent className={isLarge ? "p-4" : "p-3"}>
        <h4 className={`font-semibold mb-2 ${isLarge ? "text-lg" : "text-sm"} text-textPrimary line-clamp-2`}>
          {stream.title}
        </h4>
        
        <div className="flex items-center space-x-2 mb-2">
          <Avatar className={isLarge ? "w-8 h-8" : "w-6 h-6"}>
            <AvatarImage src={stream.streamer.profileImage || ""} />
            <AvatarFallback>{stream.streamer.displayName[0]}</AvatarFallback>
          </Avatar>
          <span className={`text-gray-400 ${isLarge ? "text-sm" : "text-xs"}`}>
            {stream.streamer.displayName}
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <Badge variant="secondary" className="text-xs">
            {stream.category}
          </Badge>
          {onGiftClick && (
            <Button
              size="sm"
              variant="ghost"
              className="text-accent hover:text-yellow-400 p-1"
              onClick={(e) => {
                e.stopPropagation();
                onGiftClick();
              }}
              data-testid={`gift-button-${stream.id}`}
            >
              <Gift className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
