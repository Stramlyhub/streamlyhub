import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Mic, MicOff, Video, VideoOff, Phone, SkipForward, Loader2 } from "lucide-react";
import { GiftPanel } from "./gift-panel";

interface VideoChatProps {
  onNext?: () => void;
  onEnd?: () => void;
}

export function VideoChat({ onNext, onEnd }: VideoChatProps) {
  const [isMatched, setIsMatched] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isSearching, setIsSearching] = useState(true);
  const [connectedUser, setConnectedUser] = useState<any>(null);

  useEffect(() => {
    // Simulate finding a match
    const timer = setTimeout(() => {
      setIsMatched(true);
      setIsSearching(false);
      setConnectedUser({
        id: "mock-user-" + Date.now(),
        displayName: "Connected User",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      });
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const handleNext = () => {
    setIsMatched(false);
    setIsSearching(true);
    setConnectedUser(null);
    onNext?.();
    
    // Simulate finding another match
    setTimeout(() => {
      setIsMatched(true);
      setIsSearching(false);
      setConnectedUser({
        id: "mock-user-" + Date.now(),
        displayName: "New User",
        profileImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      });
    }, 3000);
  };

  const handleEnd = () => {
    setIsMatched(false);
    setIsSearching(false);
    setConnectedUser(null);
    onEnd?.();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="bg-cardBg border-gray-700">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Local Video */}
            <div className="relative">
              <div className="bg-darkBg rounded-xl overflow-hidden aspect-video">
                <img 
                  src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                  alt="Your Video" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4 bg-black bg-opacity-60 text-white px-3 py-1 rounded">
                  You
                </div>
                {!isVideoOn && (
                  <div className="absolute inset-0 bg-black bg-opacity-80 flex items-center justify-center">
                    <VideoOff className="h-12 w-12 text-gray-400" />
                  </div>
                )}
              </div>
            </div>

            {/* Remote Video */}
            <div className="relative">
              <div className="bg-darkBg rounded-xl overflow-hidden aspect-video">
                {isSearching ? (
                  <div className="flex items-center justify-center h-full text-center p-8">
                    <div>
                      <Loader2 className="h-12 w-12 text-primary animate-spin mx-auto mb-4" />
                      <p className="text-xl text-gray-400">Searching for someone...</p>
                    </div>
                  </div>
                ) : isMatched && connectedUser ? (
                  <>
                    <img 
                      src={connectedUser.profileImage} 
                      alt="Connected User" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-4 left-4 bg-black bg-opacity-60 text-white px-3 py-1 rounded">
                      {connectedUser.displayName}
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full text-center p-8">
                    <div>
                      <Video className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                      <p className="text-xl text-gray-400">Ready to connect</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Chat Controls */}
          <div className="flex justify-center space-x-4 mt-6">
            <Button
              variant="outline"
              size="icon"
              className={`rounded-full border-gray-600 ${isMuted ? "bg-red-600 hover:bg-red-500" : "bg-gray-600 hover:bg-gray-500"}`}
              onClick={() => setIsMuted(!isMuted)}
              data-testid="button-toggle-mute"
            >
              {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
            <Button
              variant="outline"
              size="icon"
              className={`rounded-full border-gray-600 ${!isVideoOn ? "bg-red-600 hover:bg-red-500" : "bg-gray-600 hover:bg-gray-500"}`}
              onClick={() => setIsVideoOn(!isVideoOn)}
              data-testid="button-toggle-video"
            >
              {isVideoOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
            </Button>
            <Button
              className="bg-primary hover:bg-indigo-600 text-white px-6 rounded-full"
              onClick={handleNext}
              disabled={isSearching}
              data-testid="button-next-chat"
            >
              <SkipForward className="h-4 w-4 mr-2" />
              Next
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="bg-red-600 hover:bg-red-500 border-red-600 rounded-full"
              onClick={handleEnd}
              data-testid="button-end-chat"
            >
              <Phone className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <GiftPanel recipientId={connectedUser?.id} />
    </div>
  );
}
