import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Coins, Video, Radio, Wallet, Home, Plus, Search, Shield } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navbar() {
  const { user, signOut } = useAuth();
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/chat", label: "Video Chat", icon: Video },
    { href: "/streams", label: "Live Streams", icon: Radio },
    { href: "/discovery", label: "Discovery", icon: Search },
    { href: "/wallet", label: "Wallet", icon: Wallet },
  ];

  // Show admin link only for admin users
  if (user?.isAdmin) {
    navItems.push({ href: "/admin", label: "Admin", icon: Shield });
  }

  return (
    <nav className="bg-cardBg border-b border-gray-700 px-4 py-3 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold font-poppins text-primary">StreamlyHub</h1>
          <div className="hidden md:flex space-x-6">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className={`text-textPrimary hover:text-primary transition-colors ${
                    location === item.href ? "text-primary" : ""
                  }`}
                  data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-darkBg px-3 py-2 rounded-lg">
            <Coins className="h-4 w-4 text-accent" />
            <span className="font-semibold" data-testid="coin-balance">
              {user?.coinBalance?.toLocaleString() || 0}
            </span>
          </div>
          
          <div className="relative">
            <Avatar className="cursor-pointer border-2 border-primary" data-testid="user-avatar">
              <AvatarImage src={user?.profileImage || ""} alt="Profile" />
              <AvatarFallback>{user?.displayName?.[0] || "U"}</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>
    </nav>
  );
}

export function BottomNavigation() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/chat", label: "Chat", icon: Video },
    { href: "/streams", label: "Streams", icon: Radio },
    { href: "/discovery", label: "Discovery", icon: Search },
    { href: "/wallet", label: "Wallet", icon: Wallet },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-cardBg border-t border-gray-700 px-4 py-2 md:hidden z-50">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant="ghost"
                className={`flex flex-col items-center py-2 text-xs ${
                  location === item.href ? "text-primary" : "text-textPrimary"
                }`}
                data-testid={`mobile-nav-${item.label.toLowerCase()}`}
              >
                <Icon className="h-5 w-5 mb-1" />
                {item.label}
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function FloatingActionButton() {
  return (
    <div className="fixed bottom-20 right-6 md:bottom-6 md:right-6 z-40">
      <Button
        className="bg-gradient-to-r from-primary to-secondary text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform h-12 w-12"
        data-testid="fab-button"
      >
        <Plus className="h-6 w-6" />
      </Button>
    </div>
  );
}
