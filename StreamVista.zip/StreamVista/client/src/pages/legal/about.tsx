import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Video, Users, Heart, Shield, Globe, Zap } from "lucide-react";

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold font-poppins text-textPrimary">About StreamlyHub</h1>
        <p className="text-xl text-gray-400">
          Connecting people through live streaming and authentic conversations
        </p>
      </div>
      
      <Card className="bg-gradient-to-r from-primary to-secondary text-white border-0">
        <CardContent className="p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
          <p className="text-lg opacity-90">
            To create a vibrant community where people can connect, share experiences, 
            and build meaningful relationships through live video streaming and interactive conversations.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">What We Do</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-gray-300">
          <p>
            StreamlyHub is a comprehensive live streaming platform that combines the excitement 
            of broadcasting with the intimacy of one-on-one video chat. Our platform enables 
            creators to monetize their content through virtual gifts while building genuine 
            connections with their audience.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start space-x-4">
              <Video className="h-8 w-8 text-primary mt-1" />
              <div>
                <h3 className="font-semibold text-textPrimary mb-2">Live Streaming</h3>
                <p className="text-sm">
                  Broadcast your talents, hobbies, or daily life to a global audience 
                  with high-quality streaming technology.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <Users className="h-8 w-8 text-secondary mt-1" />
              <div>
                <h3 className="font-semibold text-textPrimary mb-2">Video Chat</h3>
                <p className="text-sm">
                  Connect with strangers or friends through our random video chat 
                  feature for authentic conversations.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <Heart className="h-8 w-8 text-accent mt-1" />
              <div>
                <h3 className="font-semibold text-textPrimary mb-2">Virtual Gifts</h3>
                <p className="text-sm">
                  Show appreciation for creators through our virtual gift system 
                  that enables real monetization.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <Shield className="h-8 w-8 text-success mt-1" />
              <div>
                <h3 className="font-semibold text-textPrimary mb-2">Safe Environment</h3>
                <p className="text-sm">
                  Advanced moderation tools and community guidelines ensure 
                  a safe and welcoming space for all users.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Our Values</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Globe className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-textPrimary mb-2">Global Community</h3>
              <p className="text-sm text-gray-400">
                Breaking down barriers and connecting people from all corners of the world.
              </p>
            </div>
            
            <div className="text-center">
              <Heart className="h-12 w-12 text-secondary mx-auto mb-4" />
              <h3 className="font-semibold text-textPrimary mb-2">Authentic Connections</h3>
              <p className="text-sm text-gray-400">
                Fostering genuine relationships built on shared interests and experiences.
              </p>
            </div>
            
            <div className="text-center">
              <Zap className="h-12 w-12 text-accent mx-auto mb-4" />
              <h3 className="font-semibold text-textPrimary mb-2">Innovation</h3>
              <p className="text-sm text-gray-400">
                Continuously improving our platform with cutting-edge technology.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Our Team</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-400 mb-6">
            StreamlyHub is built by a passionate team of developers, designers, and community 
            managers who believe in the power of human connection through technology.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Avatar className="w-24 h-24 mx-auto mb-4">
                <AvatarFallback className="text-2xl">AJ</AvatarFallback>
              </Avatar>
              <h4 className="font-semibold text-textPrimary">Alex Johnson</h4>
              <p className="text-sm text-gray-400">Founder & CEO</p>
            </div>
            
            <div className="text-center">
              <Avatar className="w-24 h-24 mx-auto mb-4">
                <AvatarFallback className="text-2xl">SC</AvatarFallback>
              </Avatar>
              <h4 className="font-semibold text-textPrimary">Sarah Chen</h4>
              <p className="text-sm text-gray-400">Head of Product</p>
            </div>
            
            <div className="text-center">
              <Avatar className="w-24 h-24 mx-auto mb-4">
                <AvatarFallback className="text-2xl">MR</AvatarFallback>
              </Avatar>
              <h4 className="font-semibold text-textPrimary">Mike Rodriguez</h4>
              <p className="text-sm text-gray-400">Lead Engineer</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Join Our Community</CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          <p className="mb-4">
            Whether you're looking to share your passion with the world, discover new 
            interests, or simply meet interesting people, StreamlyHub is the place for you.
          </p>
          <p className="text-lg font-semibold text-primary">
            Ready to start your streaming journey? Sign up today and become part of our 
            growing global community!
          </p>
        </CardContent>
      </Card>
    </div>
  );
}