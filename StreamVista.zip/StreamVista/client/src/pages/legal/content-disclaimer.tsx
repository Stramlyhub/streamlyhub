import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export default function ContentDisclaimerPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-4xl font-bold font-poppins text-textPrimary">Content Disclaimer</h1>
      <p className="text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
      
      <Card className="bg-red-900/20 border-red-500">
        <CardHeader>
          <CardTitle className="text-2xl text-red-400 flex items-center">
            <AlertTriangle className="h-6 w-6 mr-2" />
            Adult Content Warning
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p className="text-lg font-semibold text-red-400">
            This platform may contain adult content and is intended for users 18 years and older.
          </p>
          <p>
            StreamlyHub is a live streaming and video chat platform where users can interact, 
            share content, and engage in real-time communication. Due to the nature of live, 
            user-generated content, this platform may contain:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Adult themes and discussions</li>
            <li>Mature language and expressions</li>
            <li>Adult-oriented visual content</li>
            <li>Discussions of sensitive topics</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">User Responsibility</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            By using StreamlyHub, you acknowledge and agree that:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>You are at least 18 years of age</li>
            <li>You understand the nature of live streaming content</li>
            <li>You accept responsibility for your own viewing choices</li>
            <li>You will not expose minors to this platform or its content</li>
            <li>You understand that content is user-generated and not pre-screened</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Content Moderation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            While we strive to maintain a safe environment, we cannot monitor all content in real-time.
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Users can report inappropriate content</li>
            <li>We employ automated systems to detect violations</li>
            <li>Community guidelines are enforced through user reports</li>
            <li>Severe violations result in immediate account suspension</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Prohibited Content</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>The following content is strictly prohibited:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Content involving minors in any capacity</li>
            <li>Non-consensual content or activities</li>
            <li>Illegal activities or content</li>
            <li>Harassment, threats, or bullying</li>
            <li>Spam or fraudulent activities</li>
            <li>Content that violates intellectual property rights</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Disclaimer of Liability</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            StreamlyHub provides a platform for user interaction but does not endorse, 
            control, or take responsibility for user-generated content. Users interact 
            at their own risk and discretion.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Reporting and Support</CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          <p>
            To report inappropriate content or behavior, contact us at{" "}
            <a href="mailto:safety@streamlyhub.com" className="text-primary hover:underline">
              safety@streamlyhub.com
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}