import { VideoChat } from "@/components/video-chat";
import { useToast } from "@/hooks/use-toast";

export default function VideoChatPage() {
  const { toast } = useToast();

  const handleNext = () => {
    toast({
      title: "Finding next person...",
      description: "Searching for another user to connect with",
    });
  };

  const handleEnd = () => {
    toast({
      title: "Chat ended",
      description: "Thanks for using StreamlyHub video chat!",
    });
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold font-poppins text-textPrimary mb-2">
          Random Video Chat
        </h2>
        <p className="text-gray-400">
          Connect with people from around the world instantly
        </p>
      </div>
      
      <VideoChat onNext={handleNext} onEnd={handleEnd} />
    </div>
  );
}
