import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { StreamCard } from "@/components/stream-card";
import { Video, Radio, DollarSign, Heart, Eye, Gift } from "lucide-react";
import { Stream, User } from "@shared/schema";

export default function HomePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: trendingStreams = [] } = useQuery<(Stream & { streamer: User })[]>({
    queryKey: ["/api/streams/trending"],
  });

  const stats = [
    {
      label: "Total Earnings",
      value: `$${((user?.totalEarnings || 0) / 100).toFixed(2)}`,
      icon: DollarSign,
      color: "text-success",
    },
    {
      label: "Followers",
      value: (user?.followers || 0).toLocaleString(),
      icon: Heart,
      color: "text-secondary",
    },
    {
      label: "Stream Views",
      value: (user?.streamViews || 0).toLocaleString(),
      icon: Eye,
      color: "text-primary",
    },
    {
      label: "Gifts Received",
      value: (user?.giftsReceived || 0).toLocaleString(),
      icon: Gift,
      color: "text-accent",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-8 text-center">
        <h2 className="text-4xl font-bold font-poppins mb-4 text-white">
          Connect, Stream, Earn
        </h2>
        <p className="text-xl opacity-90 mb-6 text-white">
          Join thousands of creators and viewers in the ultimate live streaming experience
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={() => setLocation("/chat")}
            className="bg-white text-primary px-8 py-3 hover:bg-gray-100 font-semibold"
            data-testid="button-start-video-chat"
          >
            <Video className="h-5 w-5 mr-2" />
            Start Video Chat
          </Button>
          <Button
            onClick={() => setLocation("/streams")}
            className="bg-accent text-darkBg px-8 py-3 hover:bg-yellow-500 font-semibold"
            data-testid="button-go-live"
          >
            <Radio className="h-5 w-5 mr-2" />
            Go Live
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="bg-cardBg border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`} data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
                      {stat.value}
                    </p>
                  </div>
                  <Icon className={`${stat.color} h-6 w-6`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Trending Streams */}
      <div>
        <h3 className="text-2xl font-bold font-poppins mb-6 text-textPrimary">
          Trending Live Streams
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingStreams.slice(0, 6).map((stream) => (
            <StreamCard
              key={stream.id}
              stream={stream}
              onGiftClick={() => {
                // Handle gift sending
              }}
            />
          ))}
          {trendingStreams.length === 0 && (
            <div className="col-span-full text-center py-12">
              <Radio className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">No live streams at the moment</p>
              <p className="text-gray-500">Be the first to go live!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
