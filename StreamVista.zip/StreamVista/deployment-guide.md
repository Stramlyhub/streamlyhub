# StreamlyHub Deployment Guide for Hostinger

## Overview
This guide will walk you through deploying StreamlyHub to your Hostinger web hosting server.

## Prerequisites
- Hostinger web hosting account with Node.js support
- Firebase project with Google Authentication enabled
- Domain name configured with Hostinger

## Files Included in Deployment Package
- `dist/` - Production build files
- `package.json` - Dependencies configuration
- `deployment-guide.md` - This guide
- `.env.production.example` - Environment variables template

## Step-by-Step Deployment Instructions

### 1. Download and Extract Files
1. Download the deployment zip file from Replit
2. Extract all files to your local computer
3. You should see the `dist/` folder and configuration files

### 2. Upload Files to Hostinger
1. Log into your Hostinger account
2. Go to your hosting control panel (hPanel)
3. Open File Manager
4. Navigate to your domain's public_html folder
5. Upload ALL contents of the `dist/public/` folder to public_html
6. Upload the `dist/index.js` file to your domain root (outside public_html)
7. Upload `package.json` to your domain root

### 3. Configure Environment Variables
1. In Hostinger hPanel, go to Advanced → Environment Variables
2. Add the following variables:
   ```
   NODE_ENV=production
   VITE_FIREBASE_API_KEY=your_firebase_api_key
   VITE_FIREBASE_PROJECT_ID=your_firebase_project_id
   VITE_FIREBASE_APP_ID=your_firebase_app_id
   ```
3. Replace the values with your actual Firebase configuration

### 4. Install Dependencies
1. In Hostinger hPanel, open Terminal or SSH
2. Navigate to your domain root directory
3. Run: `npm install --production`

### 5. Configure Firebase for Your Domain
1. Go to Firebase Console → Authentication → Settings
2. Add your Hostinger domain to "Authorized domains"
   - Add: `yourdomain.com`
   - Add: `www.yourdomain.com`

### 6. Start the Application
1. In Hostinger terminal, run: `npm start`
2. Or configure it to start automatically via Hostinger's process manager

### 7. Configure Domain Routing
1. Create a `.htaccess` file in public_html with:
   ```apache
   RewriteEngine On
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule ^(.*)$ /index.html [L]
   ```

## Important Notes

### Database Setup
- The current version uses in-memory storage for development
- For production, you'll need to:
  1. Set up a PostgreSQL database on Hostinger
  2. Update the database connection in the server code
  3. Run database migrations

### SSL Certificate
- Enable SSL certificate in Hostinger for HTTPS
- Firebase requires HTTPS for authentication in production

### Performance Optimization
- Enable Gzip compression in Hostinger
- Configure browser caching for static assets
- Consider using a CDN for better performance

## Troubleshooting

### Common Issues
1. **Firebase Authentication Errors**: Check that your domain is in Firebase authorized domains
2. **404 Errors**: Ensure .htaccess file is properly configured
3. **Environment Variables**: Verify all VITE_ prefixed variables are set
4. **Node.js Version**: Ensure Hostinger supports Node.js 18+ 

### Support
- Check Hostinger documentation for Node.js hosting
- Verify your hosting plan supports Node.js applications
- Contact Hostinger support if you need help with server configuration

## File Structure After Deployment
```
yourdomain.com/
├── public_html/
│   ├── index.html
│   ├── assets/
│   │   ├── index-*.css
│   │   └── index-*.js
├── index.js (server file)
├── package.json
└── node_modules/
```

## Security Considerations
- Never expose Firebase private keys
- Use HTTPS only in production
- Regularly update dependencies
- Monitor server logs for security issues