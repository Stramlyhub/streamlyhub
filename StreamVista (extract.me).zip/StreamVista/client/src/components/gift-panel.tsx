import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Heart, Gem, Car, FlowerIcon } from "lucide-react";

interface Gift {
  id: string;
  name: string;
  icon: React.ReactNode;
  cost: number;
  color: string;
}

const gifts: Gift[] = [
  { id: "rose", name: "Rose", icon: <FlowerIcon className="h-6 w-6" />, cost: 10, color: "text-secondary" },
  { id: "heart", name: "Heart", icon: <Heart className="h-6 w-6" />, cost: 25, color: "text-red-500" },
  { id: "diamond", name: "Diamond", icon: <Gem className="h-6 w-6" />, cost: 100, color: "text-blue-400" },
  { id: "car", name: "Car", icon: <Car className="h-6 w-6" />, cost: 500, color: "text-yellow-500" },
];

interface GiftPanelProps {
  recipientId?: string;
  onGiftSent?: () => void;
}

export function GiftPanel({ recipientId, onGiftSent }: GiftPanelProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sendGiftMutation = useMutation({
    mutationFn: async ({ giftType, cost }: { giftType: string; cost: number }) => {
      const response = await apiRequest("POST", "/api/gifts/send", {
        giftType,
        cost,
        recipientId,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Gift Sent!",
        description: `You sent a ${data.giftType} for ${data.cost} coins`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      onGiftSent?.();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send gift",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSendGift = (gift: Gift) => {
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You need to be signed in to send gifts",
        variant: "destructive",
      });
      return;
    }

    if ((user.coinBalance || 0) < gift.cost) {
      toast({
        title: "Insufficient coins",
        description: "You don't have enough coins to send this gift",
        variant: "destructive",
      });
      return;
    }

    sendGiftMutation.mutate({ giftType: gift.id, cost: gift.cost });
  };

  return (
    <Card className="bg-cardBg border-gray-700">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-textPrimary">Send a Gift</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-4 gap-3">
          {gifts.map((gift) => (
            <Button
              key={gift.id}
              variant="outline"
              className="bg-darkBg hover:bg-gray-600 border-gray-600 flex flex-col items-center p-3 h-auto"
              onClick={() => handleSendGift(gift)}
              disabled={sendGiftMutation.isPending || !recipientId}
              data-testid={`gift-${gift.id}`}
            >
              <div className={gift.color}>{gift.icon}</div>
              <p className="text-xs mt-1 text-textPrimary">{gift.name}</p>
              <p className="text-xs text-accent">{gift.cost} coins</p>
            </Button>
          ))}
        </div>
        {!recipientId && (
          <p className="text-sm text-gray-400 mt-4 text-center">
            Connect with someone to send gifts
          </p>
        )}
      </CardContent>
    </Card>
  );
}
