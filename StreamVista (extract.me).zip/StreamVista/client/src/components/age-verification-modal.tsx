import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Shield } from "lucide-react";

export default function AgeVerificationModal() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Check if user has already verified their age
    const hasVerified = localStorage.getItem('age_verified');
    if (!hasVerified) {
      setIsOpen(true);
    }
  }, []);

  const handleVerify = () => {
    localStorage.setItem('age_verified', 'true');
    setIsOpen(false);
  };

  const handleDecline = () => {
    // Redirect to Google or close the app
    window.location.href = 'https://google.com';
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="bg-cardBg border-gray-700 max-w-md">{/* No close button */}
        <DialogHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center">
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          <DialogTitle className="text-2xl font-bold text-textPrimary">
            Age Verification Required
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 p-6">
          <div className="bg-red-900/20 border border-red-500 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Shield className="h-6 w-6 text-red-400 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-red-400 mb-2">Adult Content Warning</h3>
                <p className="text-gray-300 text-sm leading-relaxed">
                  StreamlyHub contains adult content and mature themes. This platform is intended 
                  for users 18 years of age or older only.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-gray-300 text-center">
              By continuing, you confirm that you are at least 18 years old and agree to our 
              terms of service and community guidelines.
            </p>
            
            <div className="space-y-3">
              <Button
                onClick={handleVerify}
                className="w-full bg-primary hover:bg-indigo-600 text-white font-semibold py-3"
                data-testid="button-verify-age"
              >
                I am 18+ years old - Continue
              </Button>
              
              <Button
                onClick={handleDecline}
                variant="outline"
                className="w-full border-gray-600 text-gray-300 hover:bg-gray-700 font-semibold py-3"
                data-testid="button-decline-age"
              >
                I am under 18 - Leave Site
              </Button>
            </div>
          </div>

          <div className="text-center">
            <p className="text-xs text-gray-500">
              This verification is required by law to protect minors from adult content.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}