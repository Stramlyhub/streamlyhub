import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Users, DollarSign, TrendingDown, TrendingUp, Shield, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { User, WithdrawalRequest } from "@shared/schema";

export default function AdminPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUserId, setSelectedUserId] = useState("");
  const [coinAmount, setCoinAmount] = useState("");

  // Redirect if not admin
  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="bg-cardBg border-gray-700">
          <CardContent className="p-8 text-center">
            <Shield className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-textPrimary mb-2">Access Denied</h2>
            <p className="text-gray-400">You don't have permission to access the admin panel.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: allUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: withdrawalRequests = [] } = useQuery<(WithdrawalRequest & { user: User })[]>({
    queryKey: ["/api/admin/withdrawal-requests"],
  });

  const processWithdrawalMutation = useMutation({
    mutationFn: async ({ id, action, note }: { id: string; action: 'approve' | 'decline'; note?: string }) => {
      const response = await apiRequest("POST", `/api/admin/withdrawal-requests/${id}/${action}`, { note });
      return response.json();
    },
    onSuccess: (data, variables) => {
      toast({
        title: `Withdrawal ${variables.action}d`,
        description: `Successfully ${variables.action}d the withdrawal request`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/withdrawal-requests"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const adjustCoinsMutation = useMutation({
    mutationFn: async ({ userId, amount }: { userId: string; amount: number }) => {
      const response = await apiRequest("POST", "/api/admin/adjust-coins", { userId, amount });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Coins adjusted",
        description: "Successfully adjusted user's coin balance",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setCoinAmount("");
      setSelectedUserId("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleProcessWithdrawal = (id: string, action: 'approve' | 'decline', note?: string) => {
    processWithdrawalMutation.mutate({ id, action, note });
  };

  const handleAdjustCoins = () => {
    if (!selectedUserId || !coinAmount) {
      toast({
        title: "Missing information",
        description: "Please select a user and enter an amount",
        variant: "destructive",
      });
      return;
    }

    const amount = parseInt(coinAmount);
    if (isNaN(amount)) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid number",
        variant: "destructive",
      });
      return;
    }

    adjustCoinsMutation.mutate({ userId: selectedUserId, amount });
  };

  const pendingWithdrawals = withdrawalRequests.filter(req => req.status === "pending");
  const totalPendingAmount = pendingWithdrawals.reduce((sum, req) => sum + req.amount, 0);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold font-poppins text-textPrimary flex items-center">
          <Shield className="h-8 w-8 mr-3 text-primary" />
          Admin Panel
        </h2>
        <Badge className="bg-primary text-white">
          Administrator
        </Badge>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-primary to-secondary text-white border-0">
          <CardContent className="p-6 text-center">
            <Users className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold" data-testid="total-users">
              {allUsers.length}
            </p>
            <p className="text-sm opacity-90">Total Users</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-accent to-orange-500 text-white border-0">
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold" data-testid="pending-withdrawals">
              {pendingWithdrawals.length}
            </p>
            <p className="text-sm opacity-90">Pending Withdrawals</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-success to-green-600 text-white border-0">
          <CardContent className="p-6 text-center">
            <DollarSign className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold" data-testid="pending-amount">
              ${(totalPendingAmount / 100).toFixed(2)}
            </p>
            <p className="text-sm opacity-90">Pending Amount</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold">
              {allUsers.filter(u => u.isStreaming).length}
            </p>
            <p className="text-sm opacity-90">Live Streamers</p>
          </CardContent>
        </Card>
      </div>

      {/* Coin Management */}
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-textPrimary">Coin Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-textPrimary mb-2">Select User</label>
              <select
                value={selectedUserId}
                onChange={(e) => setSelectedUserId(e.target.value)}
                className="w-full p-3 bg-darkBg border border-gray-600 rounded-md text-textPrimary"
                data-testid="select-user"
              >
                <option value="">Choose a user...</option>
                {allUsers.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.displayName} (@{user.username}) - {user.coinBalance} coins
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-textPrimary mb-2">
                Amount (use negative to deduct)
              </label>
              <Input
                type="number"
                value={coinAmount}
                onChange={(e) => setCoinAmount(e.target.value)}
                placeholder="e.g., 100 or -50"
                className="bg-darkBg border-gray-600 text-textPrimary"
                data-testid="input-coin-amount"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleAdjustCoins}
                disabled={adjustCoinsMutation.isPending}
                className="w-full bg-primary hover:bg-indigo-600 text-white"
                data-testid="button-adjust-coins"
              >
                {adjustCoinsMutation.isPending ? "Processing..." : "Adjust Coins"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Withdrawal Requests */}
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-textPrimary">Withdrawal Requests</CardTitle>
        </CardHeader>
        <CardContent>
          {pendingWithdrawals.length > 0 ? (
            <div className="space-y-4">
              {pendingWithdrawals.map((request) => (
                <div key={request.id} className="flex items-center justify-between p-4 bg-darkBg rounded-lg">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={request.user.profileImage || ""} />
                      <AvatarFallback>{request.user.displayName[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-textPrimary">{request.user.displayName}</p>
                      <p className="text-sm text-gray-400">@{request.user.username}</p>
                      <p className="text-sm text-gray-400">
                        Requested: {new Date(request.requestedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-success">
                      ${(request.amount / 100).toFixed(2)}
                    </p>
                    <div className="flex space-x-2 mt-2">
                      <Button
                        size="sm"
                        onClick={() => handleProcessWithdrawal(request.id, 'approve')}
                        disabled={processWithdrawalMutation.isPending}
                        className="bg-success hover:bg-emerald-600 text-white"
                        data-testid={`button-approve-${request.id}`}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleProcessWithdrawal(request.id, 'decline', 'Declined by admin')}
                        disabled={processWithdrawalMutation.isPending}
                        className="bg-red-600 hover:bg-red-500 text-white"
                        data-testid={`button-decline-${request.id}`}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Decline
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-success mx-auto mb-4" />
              <p className="text-gray-400">No pending withdrawal requests</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* All Users */}
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-textPrimary">All Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {allUsers.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-darkBg rounded-lg">
                <div className="flex items-center space-x-4">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={user.profileImage || ""} />
                    <AvatarFallback>{user.displayName[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <p className="font-semibold text-textPrimary">{user.displayName}</p>
                      {user.isAdmin && <Badge className="bg-primary text-xs">ADMIN</Badge>}
                      {user.isStreaming && <Badge className="bg-red-500 text-xs">LIVE</Badge>}
                      {user.isInVideoChat && <Badge className="bg-green-500 text-xs">CHAT</Badge>}
                    </div>
                    <p className="text-sm text-gray-400">@{user.username}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-accent">{user.coinBalance} coins</p>
                  <p className="text-sm text-gray-400">{user.followers} followers</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}