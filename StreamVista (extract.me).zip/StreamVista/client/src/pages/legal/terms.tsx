import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-4xl font-bold font-poppins text-textPrimary">Terms of Service</h1>
      <p className="text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
      
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Acceptance of Terms</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            By accessing and using StreamlyHub, you accept and agree to be bound by the terms 
            and provision of this agreement. If you do not agree to abide by the above, please 
            do not use this service.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Age Restriction</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p className="text-red-400 font-semibold">
            StreamlyHub is intended for users who are at least 18 years old.
          </p>
          <p>
            By using our service, you represent and warrant that you are at least 18 years of age. 
            If you are under 18, you are not permitted to use this service.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">User Conduct</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>Users agree not to:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Upload, post, or transmit content that is illegal, harmful, or inappropriate</li>
            <li>Harass, abuse, or harm other users</li>
            <li>Impersonate any person or entity</li>
            <li>Violate any applicable local, state, national, or international law</li>
            <li>Attempt to gain unauthorized access to our systems</li>
            <li>Interfere with the proper working of the service</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Virtual Currency</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            StreamlyHub uses a virtual currency system (coins) for transactions within the platform.
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Coins have no real-world monetary value outside of our platform</li>
            <li>Coin purchases are final and non-refundable</li>
            <li>Coin balances may be subject to expiration or forfeiture</li>
            <li>We reserve the right to modify the coin system at any time</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Content and Intellectual Property</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            Users retain ownership of content they create and share on StreamlyHub, but grant 
            us a license to use, display, and distribute such content on our platform.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Termination</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            We may terminate or suspend your account and access to the service immediately, 
            without prior notice, for conduct that we believe violates these Terms of Service.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Contact Information</CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          <p>
            Questions about the Terms of Service should be sent to{" "}
            <a href="mailto:legal@streamlyhub.com" className="text-primary hover:underline">
              legal@streamlyhub.com
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}