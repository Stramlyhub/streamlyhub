import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight, HelpCircle, MessageCircle, Video, Coins, Shield, Settings } from "lucide-react";

export default function HelpPage() {
  const [openItems, setOpenItems] = useState<string[]>([]);

  const toggleItem = (item: string) => {
    setOpenItems(prev => 
      prev.includes(item) 
        ? prev.filter(i => i !== item)
        : [...prev, item]
    );
  };

  const faqSections = [
    {
      id: "getting-started",
      title: "Getting Started",
      icon: <HelpCircle className="h-5 w-5" />,
      items: [
        {
          question: "How do I create an account?",
          answer: "Click the 'Sign Up' button and authenticate with your Google account. Your profile will be created automatically."
        },
        {
          question: "Is StreamlyHub free to use?",
          answer: "Yes! StreamlyHub is free to join and use. You can purchase coins for additional features like sending gifts."
        },
        {
          question: "What are the age requirements?",
          answer: "You must be at least 18 years old to use StreamlyHub due to the nature of live streaming content."
        }
      ]
    },
    {
      id: "streaming",
      title: "Live Streaming",
      icon: <Video className="h-5 w-5" />,
      items: [
        {
          question: "How do I start streaming?",
          answer: "Go to the Live Streams page and click 'Start Streaming'. Allow camera and microphone access when prompted."
        },
        {
          question: "What equipment do I need?",
          answer: "You only need a device with a camera and microphone. A good internet connection is recommended for quality streaming."
        },
        {
          question: "Can I stream from mobile devices?",
          answer: "Yes! StreamlyHub works on mobile devices, tablets, and desktop computers."
        }
      ]
    },
    {
      id: "video-chat",
      title: "Video Chat",
      icon: <MessageCircle className="h-5 w-5" />,
      items: [
        {
          question: "How does random video chat work?",
          answer: "Click 'Start Video Chat' and you'll be connected with another random user who is also looking to chat."
        },
        {
          question: "Can I skip to the next person?",
          answer: "Yes, you can click 'Next' to be connected with a different user at any time."
        },
        {
          question: "How do I report inappropriate behavior?",
          answer: "Use the report button during the chat session. Our team reviews all reports promptly."
        }
      ]
    },
    {
      id: "coins-gifts",
      title: "Coins & Gifts",
      icon: <Coins className="h-5 w-5" />,
      items: [
        {
          question: "What are coins used for?",
          answer: "Coins are used to purchase virtual gifts that you can send to streamers and other users to show appreciation."
        },
        {
          question: "How do I earn coins?",
          answer: "You receive coins when other users send you gifts during streams or video chats. You can also purchase coins directly."
        },
        {
          question: "Can I withdraw my earnings?",
          answer: "Yes, you can request to withdraw your earned coins. Withdrawals are processed by our admin team."
        },
        {
          question: "What are the different gift types?",
          answer: "We offer Rose (5 coins), Heart (25 coins), Diamond (100 coins), and Car (500 coins) - each with increasing value and impact."
        }
      ]
    },
    {
      id: "safety",
      title: "Safety & Privacy",
      icon: <Shield className="h-5 w-5" />,
      items: [
        {
          question: "How do you protect my privacy?",
          answer: "We use industry-standard encryption and never share your personal information with third parties without consent."
        },
        {
          question: "What should I do if I feel unsafe?",
          answer: "Immediately end the session and report the user. Contact our safety team at safety@streamlyhub.com for urgent matters."
        },
        {
          question: "Are conversations recorded?",
          answer: "No, we do not record or store video chat sessions. However, we may log certain metadata for safety purposes."
        }
      ]
    },
    {
      id: "technical",
      title: "Technical Support",
      icon: <Settings className="h-5 w-5" />,
      items: [
        {
          question: "My camera/microphone isn't working",
          answer: "Check your browser permissions and ensure you've allowed camera/microphone access for StreamlyHub."
        },
        {
          question: "The video quality is poor",
          answer: "Poor video quality is usually due to internet connection. Try closing other apps or moving closer to your router."
        },
        {
          question: "I can't connect to other users",
          answer: "This may be due to firewall or network restrictions. Try using a different network or contact your IT administrator."
        }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold font-poppins text-textPrimary">Help Center</h1>
        <p className="text-xl text-gray-400">
          Find answers to common questions and get help using StreamlyHub
        </p>
      </div>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Need immediate help?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-300">
            Can't find what you're looking for? Our support team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a 
              href="mailto:support@streamlyhub.com"
              className="flex items-center justify-center px-6 py-3 bg-primary hover:bg-indigo-600 text-white rounded-lg transition-colors"
            >
              <MessageCircle className="h-5 w-5 mr-2" />
              Email Support
            </a>
            <a 
              href="/contact"
              className="flex items-center justify-center px-6 py-3 bg-secondary hover:bg-pink-600 text-white rounded-lg transition-colors"
            >
              <HelpCircle className="h-5 w-5 mr-2" />
              Contact Form
            </a>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        {faqSections.map((section) => (
          <Card key={section.id} className="bg-cardBg border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl text-textPrimary flex items-center">
                {section.icon}
                <span className="ml-2">{section.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {section.items.map((item, index) => (
                  <Collapsible
                    key={`${section.id}-${index}`}
                    open={openItems.includes(`${section.id}-${index}`)}
                    onOpenChange={() => toggleItem(`${section.id}-${index}`)}
                  >
                    <CollapsibleTrigger className="flex items-center justify-between w-full p-4 bg-darkBg rounded-lg hover:bg-gray-700 transition-colors text-left">
                      <span className="font-medium text-textPrimary">{item.question}</span>
                      {openItems.includes(`${section.id}-${index}`) ? (
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                      ) : (
                        <ChevronRight className="h-5 w-5 text-gray-400" />
                      )}
                    </CollapsibleTrigger>
                    <CollapsibleContent className="px-4 pb-4">
                      <p className="text-gray-300 mt-2">{item.answer}</p>
                    </CollapsibleContent>
                  </Collapsible>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-to-r from-primary to-secondary text-white border-0">
        <CardContent className="p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Still need help?</h3>
          <p className="text-lg opacity-90 mb-6">
            Our friendly support team is available 24/7 to assist you with any questions or issues.
          </p>
          <a 
            href="mailto:support@streamlyhub.com"
            className="inline-flex items-center px-6 py-3 bg-white text-primary rounded-lg hover:bg-gray-100 transition-colors font-semibold"
          >
            Contact Support Team
          </a>
        </CardContent>
      </Card>
    </div>
  );
}