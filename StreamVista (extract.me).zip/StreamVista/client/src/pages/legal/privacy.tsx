import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PrivacyPolicyPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-4xl font-bold font-poppins text-textPrimary">Privacy Policy</h1>
      <p className="text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
      
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Information We Collect</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            When you use StreamlyHub, we collect information that you provide directly to us, 
            such as when you create an account, update your profile, or communicate with us.
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Account information (username, email, display name)</li>
            <li>Profile information (profile picture, bio)</li>
            <li>Payment and transaction data for coin purchases</li>
            <li>Communication data from chats and interactions</li>
            <li>Usage data and analytics to improve our service</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">How We Use Your Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>We use the information we collect to:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Provide, maintain, and improve our services</li>
            <li>Process transactions and send related information</li>
            <li>Send you technical notices and support messages</li>
            <li>Respond to your comments and questions</li>
            <li>Monitor and analyze trends and usage</li>
            <li>Detect and prevent fraudulent transactions and abuse</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Information Sharing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            We do not sell, trade, or rent your personal information to third parties. 
            We may share your information only in the following circumstances:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>With your consent or at your direction</li>
            <li>With service providers who help us operate our platform</li>
            <li>To comply with legal obligations or protect our rights</li>
            <li>In connection with a business transfer or merger</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Data Security</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-gray-300">
          <p>
            We implement appropriate security measures to protect your personal information 
            against unauthorized access, alteration, disclosure, or destruction. However, 
            no method of transmission over the internet is 100% secure.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-textPrimary">Contact Us</CardTitle>
        </CardHeader>
        <CardContent className="text-gray-300">
          <p>
            If you have any questions about this Privacy Policy, please contact us at{" "}
            <a href="mailto:privacy@streamlyhub.com" className="text-primary hover:underline">
              privacy@streamlyhub.com
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}