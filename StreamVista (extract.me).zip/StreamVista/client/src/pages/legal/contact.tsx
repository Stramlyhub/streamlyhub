import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

export default function ContactPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-4xl font-bold font-poppins text-textPrimary">Contact Us</h1>
      <p className="text-gray-400">Get in touch with our team for support, questions, or feedback.</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Contact Form */}
        <Card className="bg-cardBg border-gray-700">
          <CardHeader>
            <CardTitle className="text-2xl text-textPrimary">Send us a Message</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-textPrimary mb-2">Name</label>
              <Input
                placeholder="Your full name"
                className="bg-darkBg border-gray-600 text-textPrimary"
                data-testid="input-name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-textPrimary mb-2">Email</label>
              <Input
                type="email"
                placeholder="your.email@example.com"
                className="bg-darkBg border-gray-600 text-textPrimary"
                data-testid="input-email"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-textPrimary mb-2">Subject</label>
              <Input
                placeholder="What's this about?"
                className="bg-darkBg border-gray-600 text-textPrimary"
                data-testid="input-subject"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-textPrimary mb-2">Message</label>
              <Textarea
                placeholder="Tell us how we can help you..."
                rows={5}
                className="bg-darkBg border-gray-600 text-textPrimary"
                data-testid="textarea-message"
              />
            </div>
            <Button className="w-full bg-primary hover:bg-indigo-600 text-white" data-testid="button-send-message">
              Send Message
            </Button>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <div className="space-y-6">
          <Card className="bg-cardBg border-gray-700">
            <CardHeader>
              <CardTitle className="text-2xl text-textPrimary">Get in Touch</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-start space-x-4">
                <Mail className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold text-textPrimary">Email Support</h3>
                  <p className="text-gray-400">support@streamlyhub.com</p>
                  <p className="text-sm text-gray-500">We respond within 24 hours</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <Phone className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold text-textPrimary">Phone Support</h3>
                  <p className="text-gray-400">+1 (555) 123-4567</p>
                  <p className="text-sm text-gray-500">Mon-Fri, 9 AM - 6 PM PST</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <MapPin className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold text-textPrimary">Office Address</h3>
                  <p className="text-gray-400">
                    123 Streaming Street<br />
                    Tech City, TC 12345<br />
                    United States
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <Clock className="h-6 w-6 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold text-textPrimary">Business Hours</h3>
                  <p className="text-gray-400">
                    Monday - Friday: 9:00 AM - 6:00 PM PST<br />
                    Weekend: Emergency support only
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-cardBg border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl text-textPrimary">Quick Links</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <h4 className="font-semibold text-textPrimary">Safety & Trust</h4>
                <a href="mailto:safety@streamlyhub.com" className="text-primary hover:underline">
                  safety@streamlyhub.com
                </a>
              </div>
              <div>
                <h4 className="font-semibold text-textPrimary">Legal Inquiries</h4>
                <a href="mailto:legal@streamlyhub.com" className="text-primary hover:underline">
                  legal@streamlyhub.com
                </a>
              </div>
              <div>
                <h4 className="font-semibold text-textPrimary">Privacy Concerns</h4>
                <a href="mailto:privacy@streamlyhub.com" className="text-primary hover:underline">
                  privacy@streamlyhub.com
                </a>
              </div>
              <div>
                <h4 className="font-semibold text-textPrimary">Business Partnerships</h4>
                <a href="mailto:partnerships@streamlyhub.com" className="text-primary hover:underline">
                  partnerships@streamlyhub.com
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}