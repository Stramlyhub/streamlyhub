import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StreamCard } from "@/components/stream-card";
import { useQuery } from "@tanstack/react-query";
import { Radio, Filter } from "lucide-react";
import { Stream, User } from "@shared/schema";

const categories = [
  "All Categories",
  "Gaming",
  "Music",
  "Cooking",
  "Talk Shows",
  "Art",
  "Fitness",
  "Tech",
];

export default function LiveStreamsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All Categories");

  const { data: streams = [], isLoading } = useQuery<(Stream & { streamer: User })[]>({
    queryKey: ["/api/streams", selectedCategory],
  });

  const { data: featuredStream } = useQuery<(Stream & { streamer: User }) | null>({
    queryKey: ["/api/streams/featured"],
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-3xl font-bold font-poppins text-textPrimary">Live Streams</h2>
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="bg-cardBg border-gray-600 text-textPrimary min-w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-cardBg border-gray-600">
              {categories.map((category) => (
                <SelectItem key={category} value={category} className="text-textPrimary">
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            className="bg-accent hover:bg-yellow-500 text-darkBg font-semibold"
            data-testid="button-start-stream"
          >
            <Radio className="h-4 w-4 mr-2" />
            Go Live
          </Button>
        </div>
      </div>

      {/* Featured Stream */}
      {featuredStream && (
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 text-textPrimary">Featured Stream</h3>
          <StreamCard stream={featuredStream} size="large" />
        </div>
      )}

      {/* Stream Grid */}
      <div>
        <h3 className="text-xl font-semibold mb-4 text-textPrimary">
          {selectedCategory === "All Categories" ? "All Live Streams" : selectedCategory}
        </h3>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-cardBg rounded-xl h-48 animate-pulse" />
            ))}
          </div>
        ) : streams.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {streams.map((stream) => (
              <StreamCard
                key={stream.id}
                stream={stream}
                onGiftClick={() => {
                  // Handle gift sending
                }}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Radio className="h-16 w-16 text-gray-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-2">No streams found</h3>
            <p className="text-gray-500 mb-6">
              {selectedCategory === "All Categories" 
                ? "No one is streaming right now" 
                : `No ${selectedCategory.toLowerCase()} streams are currently live`}
            </p>
            <Button
              className="bg-primary hover:bg-indigo-600 text-white"
              data-testid="button-be-first-streamer"
            >
              Be the first to stream!
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
