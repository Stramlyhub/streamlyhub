import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Search, Users, Video, TrendingUp, Filter, Eye, Crown } from "lucide-react";
import { User } from "@shared/schema";

export default function DiscoveryPage() {
  const [sortBy, setSortBy] = useState("followers");
  
  const { data: liveStreamers = [] } = useQuery<User[]>({
    queryKey: ["/api/discovery/live-streamers"],
  });

  const { data: usersInChat = [] } = useQuery<User[]>({
    queryKey: ["/api/discovery/video-chat"],
  });

  const { data: trendingUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/discovery/trending"],
  });

  const UserCard = ({ user, showStatus = true }: { user: User; showStatus?: boolean }) => (
    <Card className="bg-cardBg border-gray-700 hover:border-primary transition-colors">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Avatar className="w-12 h-12">
              <AvatarImage src={user.profileImage || ""} alt={user.displayName} />
              <AvatarFallback>{user.displayName[0]}</AvatarFallback>
            </Avatar>
            {showStatus && user.isStreaming && (
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
            )}
            {showStatus && user.isInVideoChat && (
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2">
              <h4 className="font-semibold text-textPrimary truncate">{user.displayName}</h4>
              {user.userRank <= 3 && (
                <Crown className="h-4 w-4 text-accent" />
              )}
            </div>
            <p className="text-gray-400 text-sm">@{user.username}</p>
            <div className="flex items-center space-x-4 mt-1">
              <span className="text-sm text-gray-400">
                <Users className="h-3 w-3 inline mr-1" />
                {user.followers.toLocaleString()}
              </span>
              <span className="text-sm text-gray-400">
                <Eye className="h-3 w-3 inline mr-1" />
                {user.streamViews.toLocaleString()}
              </span>
            </div>
          </div>
          <div className="text-right">
            {user.isStreaming && (
              <Badge className="bg-red-500 hover:bg-red-500 text-white text-xs">
                LIVE
              </Badge>
            )}
            {user.isInVideoChat && (
              <Badge className="bg-green-500 hover:bg-green-500 text-white text-xs">
                CHAT
              </Badge>
            )}
            <p className="text-xs text-gray-500 mt-1">
              Rank #{user.userRank || "N/A"}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-3xl font-bold font-poppins text-textPrimary">Discovery</h2>
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="bg-cardBg border-gray-600 text-textPrimary min-w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-cardBg border-gray-600">
              <SelectItem value="followers" className="text-textPrimary">Most Followers</SelectItem>
              <SelectItem value="recent" className="text-textPrimary">Recently Active</SelectItem>
              <SelectItem value="earnings" className="text-textPrimary">Top Earners</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-r from-red-500 to-pink-500 text-white border-0">
          <CardContent className="p-6 text-center">
            <Video className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold" data-testid="live-streamers-count">
              {liveStreamers.length}
            </p>
            <p className="text-sm opacity-90">Live Streamers</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0">
          <CardContent className="p-6 text-center">
            <Users className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold" data-testid="video-chat-count">
              {usersInChat.length}
            </p>
            <p className="text-sm opacity-90">In Video Chat</p>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-primary to-secondary text-white border-0">
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-10 w-10 mx-auto mb-4" />
            <p className="text-3xl font-bold" data-testid="trending-users-count">
              {trendingUsers.length}
            </p>
            <p className="text-sm opacity-90">Trending Users</p>
          </CardContent>
        </Card>
      </div>

      {/* Live Streamers */}
      <div>
        <h3 className="text-2xl font-bold font-poppins mb-6 text-textPrimary flex items-center">
          <Video className="h-6 w-6 mr-2 text-red-500" />
          Live Streamers
        </h3>
        {liveStreamers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {liveStreamers.map((user) => (
              <UserCard key={`live-${user.id}`} user={user} />
            ))}
          </div>
        ) : (
          <Card className="bg-cardBg border-gray-700">
            <CardContent className="p-8 text-center">
              <Video className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">No one is streaming right now</p>
              <p className="text-sm text-gray-500">Be the first to go live!</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Users in Video Chat */}
      <div>
        <h3 className="text-2xl font-bold font-poppins mb-6 text-textPrimary flex items-center">
          <Users className="h-6 w-6 mr-2 text-green-500" />
          Active in Video Chat
        </h3>
        {usersInChat.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {usersInChat.map((user) => (
              <UserCard key={`chat-${user.id}`} user={user} />
            ))}
          </div>
        ) : (
          <Card className="bg-cardBg border-gray-700">
            <CardContent className="p-8 text-center">
              <Users className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">No one is in video chat right now</p>
              <p className="text-sm text-gray-500">Start a video chat to connect!</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Trending Users */}
      <div>
        <h3 className="text-2xl font-bold font-poppins mb-6 text-textPrimary flex items-center">
          <TrendingUp className="h-6 w-6 mr-2 text-accent" />
          Trending Users
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {trendingUsers.slice(0, 10).map((user, index) => (
            <div key={`trending-${user.id}`} className="relative">
              <UserCard user={user} showStatus={false} />
              <div className="absolute top-2 left-2 bg-accent text-darkBg text-xs font-bold px-2 py-1 rounded">
                #{index + 1}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}