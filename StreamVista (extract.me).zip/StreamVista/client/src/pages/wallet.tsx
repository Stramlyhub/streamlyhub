import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Coins, DollarSign, Gift, ShoppingCart, CreditCard, History, TrendingUp } from "lucide-react";
import { Transaction } from "@shared/schema";

const coinPackages = [
  { id: "100", coins: 100, price: 0.99, popular: false },
  { id: "500", coins: 500, price: 4.99, popular: true },
  { id: "1000", coins: 1000, price: 9.99, bestValue: true },
  { id: "5000", coins: 5000, price: 49.99, popular: false },
];

export default function WalletPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const purchaseCoinsMutation = useMutation({
    mutationFn: async (packageId: string) => {
      const response = await apiRequest("POST", "/api/wallet/purchase", { packageId });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Purchase successful!",
        description: "Coins have been added to your account",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Purchase failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (amount: number) => {
      const response = await apiRequest("POST", "/api/wallet/withdraw", { amount });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal requested",
        description: "Your withdrawal request has been submitted",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePurchase = (packageId: string) => {
    purchaseCoinsMutation.mutate(packageId);
  };

  const handleWithdraw = () => {
    const withdrawableAmount = Math.floor((user?.totalEarnings || 0) / 100);
    if (withdrawableAmount < 10) {
      toast({
        title: "Minimum withdrawal not met",
        description: "You need at least $10.00 to withdraw",
        variant: "destructive",
      });
      return;
    }
    withdrawMutation.mutate(withdrawableAmount);
  };

  const walletStats = [
    {
      title: "Current Balance",
      value: (user?.coinBalance || 0).toLocaleString(),
      subtitle: "coins",
      icon: Coins,
      gradient: "from-primary to-secondary",
    },
    {
      title: "Total Earnings",
      value: `$${((user?.totalEarnings || 0) / 100).toFixed(2)}`,
      subtitle: "USD",
      icon: DollarSign,
      gradient: "from-success to-green-600",
    },
    {
      title: "Gifts Received",
      value: (user?.giftsReceived || 0).toLocaleString(),
      subtitle: "total gifts",
      icon: Gift,
      gradient: "from-accent to-orange-500",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h2 className="text-3xl font-bold font-poppins text-textPrimary">Wallet & Earnings</h2>
      
      {/* Wallet Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {walletStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className={`bg-gradient-to-r ${stat.gradient} text-white border-0`}>
              <CardContent className="p-6 text-center">
                <Icon className="h-10 w-10 mx-auto mb-4" />
                <p className="text-sm opacity-90">{stat.title}</p>
                <p className="text-3xl font-bold" data-testid={`wallet-${stat.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {stat.value}
                </p>
                <p className="text-sm opacity-75">{stat.subtitle}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-textPrimary">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              className="bg-primary hover:bg-indigo-600 text-white p-6 h-auto flex flex-col"
              data-testid="button-buy-coins"
            >
              <ShoppingCart className="h-6 w-6 mb-2" />
              <p className="font-semibold">Buy Coins</p>
              <p className="text-sm opacity-90">Purchase more coins</p>
            </Button>
            <Button
              onClick={handleWithdraw}
              disabled={withdrawMutation.isPending || (user?.totalEarnings || 0) < 1000}
              className="bg-success hover:bg-emerald-600 text-white p-6 h-auto flex flex-col disabled:opacity-50"
              data-testid="button-withdraw"
            >
              <TrendingUp className="h-6 w-6 mb-2" />
              <p className="font-semibold">Withdraw</p>
              <p className="text-sm opacity-90">Cash out earnings</p>
            </Button>
            <Button
              variant="outline"
              className="border-gray-600 text-textPrimary hover:bg-gray-700 p-6 h-auto flex flex-col"
              data-testid="button-transaction-history"
            >
              <History className="h-6 w-6 mb-2" />
              <p className="font-semibold">Transaction History</p>
              <p className="text-sm opacity-90">View all transactions</p>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Coin Packages */}
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-textPrimary">Coin Packages</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {coinPackages.map((pkg) => (
              <Card
                key={pkg.id}
                className="bg-darkBg border-gray-600 hover:border-primary transition-colors cursor-pointer relative"
              >
                {pkg.popular && (
                  <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-secondary">
                    POPULAR
                  </Badge>
                )}
                {pkg.bestValue && (
                  <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-accent text-darkBg">
                    BEST VALUE
                  </Badge>
                )}
                <CardContent className="p-4 text-center">
                  <Coins className="h-8 w-8 text-accent mx-auto mb-2" />
                  <p className="font-bold text-lg text-textPrimary">{pkg.coins} Coins</p>
                  <p className="text-success text-xl font-bold">${pkg.price}</p>
                  <Button
                    onClick={() => handlePurchase(pkg.id)}
                    disabled={purchaseCoinsMutation.isPending}
                    className="w-full bg-primary hover:bg-indigo-600 text-white mt-3"
                    data-testid={`button-purchase-${pkg.coins}-coins`}
                  >
                    {purchaseCoinsMutation.isPending ? "Processing..." : "Buy Now"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Transaction History */}
      <Card className="bg-cardBg border-gray-700">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-textPrimary">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactions.length > 0 ? (
              transactions.slice(0, 10).map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-4 bg-darkBg rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`p-2 rounded-full ${
                      transaction.type === 'gift_received' ? 'bg-success' :
                      transaction.type === 'gift_sent' ? 'bg-secondary' :
                      transaction.type === 'coin_purchase' ? 'bg-primary' :
                      'bg-accent'
                    }`}>
                      {transaction.type === 'gift_received' || transaction.type === 'gift_sent' ? (
                        <Gift className="h-4 w-4 text-white" />
                      ) : transaction.type === 'coin_purchase' ? (
                        <CreditCard className="h-4 w-4 text-white" />
                      ) : (
                        <TrendingUp className="h-4 w-4 text-white" />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold text-textPrimary">{transaction.description}</p>
                      <p className="text-sm text-gray-400">
                        {new Date(transaction.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${
                      transaction.amount > 0 ? 'text-success' : 'text-red-400'
                    }`}>
                      {transaction.amount > 0 ? '+' : ''}{transaction.amount} coins
                    </p>
                    {transaction.fromUserId && (
                      <p className="text-sm text-gray-400">From User ID: {transaction.fromUserId}</p>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <History className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                <p className="text-gray-400">No transactions yet</p>
                <p className="text-sm text-gray-500">Your transaction history will appear here</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
