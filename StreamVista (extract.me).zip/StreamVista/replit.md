# Overview

StreamlyHub is a live streaming platform that combines social video features with a virtual economy. Users can stream content, participate in random video chat, send virtual gifts, and earn coins through viewer engagement. The application provides a TikTok-like experience with monetization features for content creators.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built with React using Vite as the build tool and TypeScript for type safety. The application uses a component-based architecture with:

- **Routing**: Wouter for client-side routing with protected routes requiring authentication
- **State Management**: TanStack Query for server state management and caching
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Authentication**: Firebase Authentication with Google OAuth integration
- **Real-time Features**: Mock implementation for video chat functionality

The application follows a mobile-first responsive design with both desktop and mobile navigation patterns. Custom CSS variables provide a dark theme optimized for streaming content.

## Backend Architecture

The backend uses Express.js with TypeScript in a monolithic architecture:

- **Server Framework**: Express.js with middleware for request logging and error handling
- **Development Setup**: Vite integration for hot module replacement in development
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development
- **API Design**: RESTful endpoints organized by feature (auth, streams, transactions, gifts)

The server implements a mock authentication middleware that simulates Firebase token verification for development purposes.

## Data Storage Solutions

The application uses a dual storage approach:

- **Production Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Development Storage**: In-memory storage implementation with seeded data for rapid development
- **Database Schema**: Normalized relational design with tables for users, streams, transactions, and followers
- **Connection**: Neon Database serverless PostgreSQL for cloud deployment

The storage layer is abstracted through an interface pattern, allowing easy switching between implementations.

## Authentication and Authorization

Authentication is handled through Firebase Auth with Google OAuth:

- **Provider**: Firebase Authentication with Google as the primary sign-in method
- **Token Management**: JWT tokens from Firebase are passed to the backend for user identification
- **User Registration**: Automatic user creation in the database upon first Firebase authentication
- **Route Protection**: Frontend route guards that redirect unauthenticated users to the auth page
- **Session Management**: Firebase handles session persistence and token refresh

## Gift Economy System

The platform implements a virtual economy with coins and gifts:

- **Virtual Currency**: Coins serve as the primary currency for transactions
- **Gift Types**: Four gift tiers (Rose, Heart, Diamond, Car) with increasing costs
- **Transaction Tracking**: Complete audit trail of all coin transactions and gift exchanges
- **Revenue Sharing**: Streamers earn coins from received gifts that can be converted to real currency

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting for production data storage
- **Drizzle ORM**: Type-safe database toolkit for schema management and queries

## Authentication Services
- **Firebase Authentication**: User authentication and session management
- **Google OAuth**: Primary authentication provider for user sign-in

## Frontend Libraries
- **React**: Core UI framework with hooks and modern patterns
- **TanStack Query**: Server state management and caching solution
- **Wouter**: Lightweight client-side routing library
- **Shadcn/ui**: Component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework for styling

## Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Static type checking across the entire application
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment integration with runtime error handling