import { type User, type InsertUser, type Transaction, type InsertTransaction, type Stream, type InsertStream, type Follower, type InsertFollower, type WithdrawalRequest, type InsertWithdrawalRequest } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;

  // Transactions
  getTransactionsByUserId(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Streams
  getStreams(category?: string): Promise<(Stream & { streamer: User })[]>;
  getTrendingStreams(): Promise<(Stream & { streamer: User })[]>;
  getFeaturedStream(): Promise<(Stream & { streamer: User }) | undefined>;
  createStream(stream: InsertStream): Promise<Stream>;
  updateStream(id: string, updates: Partial<Stream>): Promise<Stream>;

  // Followers
  getFollowers(userId: string): Promise<Follower[]>;
  createFollower(follower: InsertFollower): Promise<Follower>;
  deleteFollower(followerId: string, followingId: string): Promise<void>;

  // Discovery
  getLiveStreamers(): Promise<User[]>;
  getUsersInVideoChat(): Promise<User[]>;
  getTrendingUsers(): Promise<User[]>;

  // Admin/Withdrawals
  getWithdrawalRequests(): Promise<(WithdrawalRequest & { user: User })[]>;
  createWithdrawalRequest(request: InsertWithdrawalRequest): Promise<WithdrawalRequest>;
  updateWithdrawalRequest(id: string, updates: Partial<WithdrawalRequest>): Promise<WithdrawalRequest>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private transactions: Map<string, Transaction>;
  private streams: Map<string, Stream>;
  private followers: Map<string, Follower>;
  private withdrawalRequests: Map<string, WithdrawalRequest>;

  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.streams = new Map();
    this.followers = new Map();
    this.withdrawalRequests = new Map();
    this.seedData();
  }

  private seedData() {
    // Create sample streamers and streams
    const sampleUsers = [
      {
        id: "user-1",
        firebaseUid: "firebase-1",
        username: "GamerPro_Alex",
        email: "alex@example.com",
        displayName: "Alex Gaming",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
        coinBalance: 500,
        totalEarnings: 2450,
        followers: 12400,
        following: 150,
        streamViews: 85200,
        giftsReceived: 892,
        isStreaming: true,
        isInVideoChat: false,
        userRank: 1,
        lastActive: new Date(),
        isAdmin: false,
        createdAt: new Date(),
      },
      {
        id: "user-2",
        firebaseUid: "firebase-2",
        username: "MelodyMaker_Sarah",
        email: "sarah@example.com",
        displayName: "Sarah Music",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
        coinBalance: 750,
        totalEarnings: 1890,
        followers: 8500,
        following: 200,
        streamViews: 42000,
        giftsReceived: 654,
        isStreaming: true,
        isInVideoChat: false,
        userRank: 2,
        lastActive: new Date(),
        isAdmin: false,
        createdAt: new Date(),
      },
      {
        id: "user-3",
        firebaseUid: "firebase-3",
        username: "ChefMario_Official",
        email: "mario@example.com",
        displayName: "Chef Mario",
        profileImage: "https://images.unsplash.com/photo-1583394293214-28ded15ee548?w=150",
        coinBalance: 300,
        totalEarnings: 890,
        followers: 3200,
        following: 80,
        streamViews: 15000,
        giftsReceived: 234,
        isStreaming: true,
        isInVideoChat: false,
        userRank: 3,
        lastActive: new Date(),
        isAdmin: false,
        createdAt: new Date(),
      },
    ];

    sampleUsers.forEach(user => this.users.set(user.id, user));

    // Create sample streams
    const sampleStreams = [
      {
        id: "stream-1",
        streamerId: "user-1",
        title: "Epic Gaming Session - Come Chat!",
        category: "Gaming",
        thumbnail: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400",
        isLive: true,
        viewerCount: 2300,
        createdAt: new Date(),
      },
      {
        id: "stream-2",
        streamerId: "user-2",
        title: "Acoustic Covers & Original Songs",
        category: "Music",
        thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400",
        isLive: true,
        viewerCount: 1800,
        createdAt: new Date(),
      },
      {
        id: "stream-3",
        streamerId: "user-3",
        title: "Italian Pasta Making Tutorial",
        category: "Cooking",
        thumbnail: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400",
        isLive: true,
        viewerCount: 965,
        createdAt: new Date(),
      },
    ];

    sampleStreams.forEach(stream => this.streams.set(stream.id, stream));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.firebaseUid === firebaseUid);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      profileImage: insertUser.profileImage || null,
      coinBalance: insertUser.coinBalance || 100,
      totalEarnings: insertUser.totalEarnings || 0,
      followers: insertUser.followers || 0,
      following: insertUser.following || 0,
      streamViews: insertUser.streamViews || 0,
      giftsReceived: insertUser.giftsReceived || 0,
      isStreaming: insertUser.isStreaming || false,
      isInVideoChat: insertUser.isInVideoChat || false,
      userRank: insertUser.userRank || 0,
      lastActive: new Date(),
      isAdmin: insertUser.isAdmin || false,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getTransactionsByUserId(userId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(t => t.userId === userId);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      fromUserId: insertTransaction.fromUserId || null,
      toUserId: insertTransaction.toUserId || null,
      giftType: insertTransaction.giftType || null,
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getStreams(category?: string): Promise<(Stream & { streamer: User })[]> {
    const streams = Array.from(this.streams.values());
    const filteredStreams = category && category !== "All Categories" 
      ? streams.filter(s => s.category === category)
      : streams;
      
    return filteredStreams.map(stream => ({
      ...stream,
      streamer: this.users.get(stream.streamerId)!,
    }));
  }

  async getTrendingStreams(): Promise<(Stream & { streamer: User })[]> {
    const streams = Array.from(this.streams.values())
      .sort((a, b) => (b.viewerCount || 0) - (a.viewerCount || 0))
      .slice(0, 6);
      
    return streams.map(stream => ({
      ...stream,
      streamer: this.users.get(stream.streamerId)!,
    }));
  }

  async getFeaturedStream(): Promise<(Stream & { streamer: User }) | undefined> {
    const streams = Array.from(this.streams.values());
    if (streams.length === 0) return undefined;
    
    const featured = streams.reduce((prev, current) => 
      (current.viewerCount || 0) > (prev.viewerCount || 0) ? current : prev
    );
    
    return {
      ...featured,
      streamer: this.users.get(featured.streamerId)!,
    };
  }

  async createStream(insertStream: InsertStream): Promise<Stream> {
    const id = randomUUID();
    const stream: Stream = {
      ...insertStream,
      id,
      thumbnail: insertStream.thumbnail || null,
      isLive: true,
      viewerCount: 0,
      createdAt: new Date(),
    };
    this.streams.set(id, stream);
    return stream;
  }

  async updateStream(id: string, updates: Partial<Stream>): Promise<Stream> {
    const stream = this.streams.get(id);
    if (!stream) throw new Error("Stream not found");
    
    const updatedStream = { ...stream, ...updates };
    this.streams.set(id, updatedStream);
    return updatedStream;
  }

  async getFollowers(userId: string): Promise<Follower[]> {
    return Array.from(this.followers.values()).filter(f => f.followingId === userId);
  }

  async createFollower(insertFollower: InsertFollower): Promise<Follower> {
    const id = randomUUID();
    const follower: Follower = {
      ...insertFollower,
      id,
      createdAt: new Date(),
    };
    this.followers.set(id, follower);
    return follower;
  }

  async deleteFollower(followerId: string, followingId: string): Promise<void> {
    const entries = Array.from(this.followers.entries());
    for (const [id, follower] of entries) {
      if (follower.followerId === followerId && follower.followingId === followingId) {
        this.followers.delete(id);
        break;
      }
    }
  }

  async getLiveStreamers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isStreaming);
  }

  async getUsersInVideoChat(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isInVideoChat);
  }

  async getTrendingUsers(): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.followers - a.followers)
      .slice(0, 20);
  }

  async getWithdrawalRequests(): Promise<(WithdrawalRequest & { user: User })[]> {
    return Array.from(this.withdrawalRequests.values()).map(request => ({
      ...request,
      user: this.users.get(request.userId)!,
    }));
  }

  async createWithdrawalRequest(insertRequest: InsertWithdrawalRequest): Promise<WithdrawalRequest> {
    const id = randomUUID();
    const request: WithdrawalRequest = {
      ...insertRequest,
      id,
      status: "pending",
      requestedAt: new Date(),
      processedAt: null,
      adminNote: null,
    };
    this.withdrawalRequests.set(id, request);
    return request;
  }

  async updateWithdrawalRequest(id: string, updates: Partial<WithdrawalRequest>): Promise<WithdrawalRequest> {
    const request = this.withdrawalRequests.get(id);
    if (!request) throw new Error("Withdrawal request not found");
    
    const updatedRequest = { ...request, ...updates };
    this.withdrawalRequests.set(id, updatedRequest);
    return updatedRequest;
  }
}

export const storage = new MemStorage();
