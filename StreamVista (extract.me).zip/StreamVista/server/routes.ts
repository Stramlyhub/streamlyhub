import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertTransactionSchema, insertWithdrawalRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware to extract Firebase user from token
  const requireAuth = async (req: any, res: any, next: any) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader?.startsWith('Bearer ')) {
        return res.status(401).json({ message: "No token provided" });
      }

      // In a real app, you'd verify the Firebase token here
      // For this MVP, we'll extract user from mock token
      const token = authHeader.split(' ')[1];
      req.firebaseUid = token; // Mock - normally you'd decode the JWT
      next();
    } catch (error) {
      res.status(401).json({ message: "Invalid token" });
    }
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/auth/me", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stream routes
  app.get("/api/streams", async (req, res) => {
    try {
      const category = req.query.category as string;
      const streams = await storage.getStreams(category);
      res.json(streams);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/streams/trending", async (req, res) => {
    try {
      const streams = await storage.getTrendingStreams();
      res.json(streams);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/streams/featured", async (req, res) => {
    try {
      const stream = await storage.getFeaturedStream();
      res.json(stream);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Gift system
  app.post("/api/gifts/send", requireAuth, async (req: any, res) => {
    try {
      const { giftType, cost, recipientId } = req.body;
      
      const sender = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!sender) {
        return res.status(404).json({ message: "Sender not found" });
      }

      if (sender.coinBalance < cost) {
        return res.status(400).json({ message: "Insufficient coins" });
      }

      // Update sender's balance
      await storage.updateUser(sender.id, {
        coinBalance: sender.coinBalance - cost,
      });

      // Update recipient's balance and gift count
      if (recipientId) {
        const recipient = await storage.getUser(recipientId);
        if (recipient) {
          await storage.updateUser(recipientId, {
            coinBalance: recipient.coinBalance + cost,
            totalEarnings: recipient.totalEarnings + cost,
            giftsReceived: recipient.giftsReceived + 1,
          });

          // Record gift received transaction
          await storage.createTransaction({
            userId: recipientId,
            type: "gift_received",
            amount: cost,
            description: `Received ${giftType} gift`,
            fromUserId: sender.id,
            giftType,
          });
        }
      }

      // Record gift sent transaction
      await storage.createTransaction({
        userId: sender.id,
        type: "gift_sent",
        amount: -cost,
        description: `Sent ${giftType} gift`,
        toUserId: recipientId,
        giftType,
      });

      res.json({ giftType, cost, recipientId });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Wallet routes
  app.post("/api/wallet/purchase", requireAuth, async (req: any, res) => {
    try {
      const { packageId } = req.body;
      
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Mock coin packages
      const packages: Record<string, { coins: number; price: number }> = {
        "100": { coins: 100, price: 99 },
        "500": { coins: 500, price: 499 },
        "1000": { coins: 1000, price: 999 },
        "5000": { coins: 5000, price: 4999 },
      };

      const pkg = packages[packageId];
      if (!pkg) {
        return res.status(400).json({ message: "Invalid package" });
      }

      // Update user's coin balance
      await storage.updateUser(user.id, {
        coinBalance: user.coinBalance + pkg.coins,
      });

      // Record purchase transaction
      await storage.createTransaction({
        userId: user.id,
        type: "coin_purchase",
        amount: pkg.coins,
        description: `Purchased ${pkg.coins} coins for $${(pkg.price / 100).toFixed(2)}`,
      });

      res.json({ success: true, coins: pkg.coins, price: pkg.price });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/wallet/withdraw", requireAuth, async (req: any, res) => {
    try {
      const { amount } = req.body;
      
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.totalEarnings < amount * 100) {
        return res.status(400).json({ message: "Insufficient earnings" });
      }

      // Record withdrawal transaction
      await storage.createTransaction({
        userId: user.id,
        type: "withdrawal",
        amount: -amount * 100,
        description: `Withdrawal request for $${amount.toFixed(2)}`,
      });

      res.json({ success: true, amount });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Transaction history
  app.get("/api/transactions", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const transactions = await storage.getTransactionsByUserId(user.id);
      res.json(transactions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Discovery routes
  app.get("/api/discovery/live-streamers", async (req, res) => {
    try {
      const streamers = await storage.getLiveStreamers();
      res.json(streamers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/discovery/video-chat", async (req, res) => {
    try {
      const users = await storage.getUsersInVideoChat();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/discovery/trending", async (req, res) => {
    try {
      const users = await storage.getTrendingUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Admin routes
  app.get("/api/admin/users", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/withdrawal-requests", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const requests = await storage.getWithdrawalRequests();
      res.json(requests);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/withdrawal-requests/:id/:action", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { id, action } = req.params;
      const { note } = req.body;
      
      if (action !== 'approve' && action !== 'decline') {
        return res.status(400).json({ message: "Invalid action" });
      }
      
      const updatedRequest = await storage.updateWithdrawalRequest(id, {
        status: action === 'approve' ? 'approved' : 'declined',
        processedAt: new Date(),
        adminNote: note || null,
      });
      
      res.json(updatedRequest);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/adjust-coins", requireAuth, async (req: any, res) => {
    try {
      const admin = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!admin?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { userId, amount } = req.body;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const newBalance = Math.max(0, user.coinBalance + amount);
      await storage.updateUser(userId, { coinBalance: newBalance });
      
      // Record transaction
      await storage.createTransaction({
        userId,
        type: amount > 0 ? "admin_credit" : "admin_debit",
        amount,
        description: `Admin ${amount > 0 ? 'added' : 'removed'} ${Math.abs(amount)} coins`,
      });
      
      res.json({ success: true, newBalance });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Withdrawal request route
  app.post("/api/wallet/request-withdrawal", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { amount } = req.body;
      
      if (amount > user.coinBalance) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      if (amount < 100) {
        return res.status(400).json({ message: "Minimum withdrawal is 100 coins" });
      }
      
      const request = await storage.createWithdrawalRequest({
        userId: user.id,
        amount,
      });
      
      res.json(request);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
